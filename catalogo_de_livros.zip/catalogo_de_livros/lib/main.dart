import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catálogo de Livros',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: ListaDeLivros(),
    );
  }
}

class ListaDeLivros extends StatelessWidget {
  final List<Map<String, String>> livros = [
    {'titulo': 'Livro 1', 'imagem': 'assets/como fazer amigos e influenciar pessoas.png'},
    {'titulo': 'Livro 2', 'imagem': 'assets/da manha para se tornar.jpg.jpg'},
    {'titulo': 'Livro 3', 'imagem': 'assets/especialista em pessoas.png'},
    {'titulo': 'Livro 4', 'imagem': 'assets/mais esperto.jpg'},
    {'titulo': 'Livro 5', 'imagem': 'assets/mindset.jpg'},
    {'titulo': 'Livro 6', 'imagem': 'assets/o poder hábito.png'},
    {'titulo': 'Livro 7', 'imagem': 'assets/pai rico pai pobre.jpg'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Livros'),
      ),
      body: ListView.builder(
        itemCount: livros.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Image.asset(livros[index]['imagem']!),
            title: Text(livros[index]['titulo']!),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AdicionarLivro()),
          );
        },
        child: Icon(Icons.edit),
      ),
    );
  }
}

class AdicionarLivro extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Novo Livro'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Nome do livro',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              decoration: InputDecoration(
                labelText: 'Nome do autor',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              decoration: InputDecoration(
                labelText: 'Descrição',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Ação ao confirmar a adição
              },
              child: Text('Confirmar'),
            ),
          ],
        ),
      ),
    );
  }
}

class ExcluirLivros extends StatelessWidget {
  final List<Map<String, String>> livros = [
    {'titulo': 'Livro 1', 'imagem': 'assets/livro1.jpg'},
    {'titulo': 'Livro 2', 'imagem': 'assets/livro2.jpg'},
    {'titulo': 'Livro 3', 'imagem': 'assets/livro3.jpg'},
    {'titulo': 'Livro 4', 'imagem': 'assets/livro4.jpg'},
    {'titulo': 'Livro 5', 'imagem': 'assets/livro5.jpg'},
    {'titulo': 'Livro 6', 'imagem': 'assets/livro6.jpg'},
    {'titulo': 'Livro 7', 'imagem': 'assets/livro7.jpg'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Excluir Livros'),
      ),
      body: ListView.builder(
        itemCount: livros.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Image.asset(livros[index]['imagem']!),
            title: Text(livros[index]['titulo']!),
            trailing: ElevatedButton(
              onPressed: () {
                // Ação ao deletar o livro
              },
              child: Text('Deletar'),
              style: ElevatedButton.styleFrom(primary: Colors.red),
            ),
          );
        },
      ),
    );
  }
}
